
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import model.CSVSerializable;
import persistence.PersistenciaPersonaje;
import java.util.ArrayList;


public class ColeccionPersonajes<T extends CSVSerializable> {

    private List<T> lista;
    
    public ColeccionPersonajes() {
        this.lista = new ArrayList<>();
    }   

    public void agregar(T elem) {
        lista.add(elem);
    }


    public List<T> filtrar(Predicate<T> criterio) {
        return lista.stream().filter(criterio).toList();

    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        lista.forEach(accion);
    }

    public void ordenarNatural() {
        lista.sort(null); 
    }

    public void ordenar(Comparator<T> cmp) {
        lista.sort(cmp);
    }
    
    public void guardarEnCSV(String path) throws IOException {
        PersistenciaPersonaje.guardarPersonajesCSV(
                (List<Personaje>) lista, path);
    }

    public List<Personaje> cargarDesdeCSV(String path) throws IOException {
        List<Personaje> cargados = PersistenciaPersonaje.cargarPersonajesCSV(path);
        lista = (List<T>) cargados;
        return cargados;
    }

    public void guardarEnArchivo(String path) throws IOException {
        PersistenciaPersonaje.serializarPersonajes(
                (List<Personaje>) lista, path);
    }

    public List<Personaje> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        List<Personaje> cargados = PersistenciaPersonaje.deserializarPersonajes(path);
        lista = (List<T>) cargados;
        return cargados;
    }

    
    
    
}
