package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import model.Personaje;

public interface PersistenciaPersonaje {

    static void guardarPersonajesCSV(List<? extends Personaje> lista, String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write(Personaje.getHeaderCSV());
            escritor.newLine();

            for (Personaje p : lista) {
                escritor.write(p.toCSV());
                escritor.newLine();
            }
        }
    }

    static List<Personaje> cargarPersonajesCSV(String path) throws IOException {
        List<Personaje> toReturn = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {

            lector.readLine();

            String datos;
            while ((datos = lector.readLine()) != null) {
                toReturn.add(Personaje.fromCSV(datos));
            }
        }
        return toReturn;
    }

    static void serializarPersonajes(List<? extends Personaje> lista, String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }
    }

    static List<Personaje> deserializarPersonajes(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            return (List<Personaje>) entrada.readObject();
        }
    }
}