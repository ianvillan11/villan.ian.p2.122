
package repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import model.CSVSerializable;


public class ColeccionPersonajes<T extends CSVSerializable & Comparable<T>> {

    private List<T> lista = new ArrayList<>();

    public void agregar(T elem) {
        lista.add(elem);
    }


    public List<T> filtrar(Predicate<T> criterio) {
        return lista.stream().filter(criterio).toList();

    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        lista.forEach(accion);
    }

    public void ordenarNatural() {
        lista.sort(null); 
    }

    public void ordenar(Comparator<T> cmp) {
        lista.sort(cmp);
    }

    
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }
    }
    
    
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            List<?> cargado = (List<?>) entrada.readObject(); 
            lista.clear();
            for (Object obj : cargado) {
                lista.add((T) obj); 
            }
        }
    }

   
   

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            for (T elem : lista) {
                escritor.write(elem.toCSV());
                escritor.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> parser) throws IOException {
        lista.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                lista.add(parser.apply(linea));
            }
        }
    }
}
