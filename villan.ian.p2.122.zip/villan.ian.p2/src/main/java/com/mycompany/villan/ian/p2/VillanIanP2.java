package com.mycompany.villan.ian.p2;

import java.io.IOException;
import model.Personaje;
import model.RolPersonaje;
import repository.ColeccionPersonajes;

public class VillanIanP2 {

    public static void main(String[] args) {
        try {
            ColeccionPersonajes<Personaje> coleccion = new ColeccionPersonajes<>();

            coleccion.agregar(new Personaje(1, "Arthas", "Blizzard", RolPersonaje.TANQUE));
            coleccion.agregar(new Personaje(2, "Zelda Mage", "Nintendo", RolPersonaje.MAGO));
            coleccion.agregar(new Personaje(3, "Shadow Archer", "Sega", RolPersonaje.ARQUERO));
            coleccion.agregar(new Personaje(4, "MedBot 2.0", "Valve", RolPersonaje.SANADOR));
            coleccion.agregar(new Personaje(5, "Tech Engineer", "Capcom", RolPersonaje.INGENIERO));

            // Mostrar todos
            System.out.println("Personajes:");
            coleccion.paraCadaElemento(p -> System.out.println(p));

            // Filtrar por rol MAGO
            System.out.println("\nPersonajes MAGO:");
            coleccion.filtrar(p -> p.getRol() == RolPersonaje.MAGO)
                     .forEach(p -> System.out.println(p));

            // Filtrar por nombre que contenga "Shadow"
            System.out.println("\nPersonajes que contienen 'Shadow':");
            coleccion.filtrar(p -> p.getNombre().toLowerCase().contains("shadow"))
                     .forEach(p -> System.out.println(p));

            // Ordenar por ID (orden natural)
            System.out.println("\nPersonajes ordenados por ID:");
            coleccion.ordenarNatural();
            coleccion.paraCadaElemento(p -> System.out.println(p));

            // Ordenar por nombre
            System.out.println("\nPersonajes ordenados por nombre:");
            coleccion.ordenar((a, b) -> a.getNombre().compareToIgnoreCase(b.getNombre()));
            coleccion.paraCadaElemento(p -> System.out.println(p));

            // Guardar en binario
            coleccion.guardarEnArchivo("src/main/java/resources/personajes.dat");

            // Cargar desde binario
            ColeccionPersonajes<Personaje> cargado = new ColeccionPersonajes<>();
            cargado.cargarDesdeArchivo("src/main/java/resources/personajes.dat");

            System.out.println("\nPersonajes cargados desde archivo binario:");
            cargado.paraCadaElemento(p -> System.out.println(p));

            // Guardar en CSV
            coleccion.guardarEnCSV("src/main/java/resources/personajes.csv");

            // Cargar desde CSV
            cargado.cargarDesdeCSV("src/main/java/resources/personajes.csv",
                    linea -> Personaje.fromCSV(linea));

            System.out.println("\nPersonajes cargados desde archivo CSV:");
            cargado.paraCadaElemento(p -> System.out.println(p));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}