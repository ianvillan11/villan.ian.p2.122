
package model;

import java.io.Serializable;

public class Personaje implements CSVSerializable,Comparable<Personaje>,Serializable { 

   
    
    private final int id;
    private final String nombre;
    private final String creador;
    private final RolPersonaje rol;
    
    public Personaje(int id,String nombre,String creador,RolPersonaje rol){
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.rol = rol;
    }
    
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public RolPersonaje getRol() {
        return rol;
    }
    
    
    
    @Override
    public String toString() {
        return "Personaje{id=" + id + ", nombre='" + nombre + ", creador='" + creador + ", rol=" + rol + '}';
    }
    
    @Override
    public int compareTo(Personaje otro) {
        return Integer.compare(this.id, otro.id);
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + rol;
    }
    
    
    public static Personaje fromCSV(String personajeCSV) {
        String[] datos = personajeCSV.split(",");

        return new Personaje(
                Integer.parseInt(datos[0]),    
                datos[1],                      
                datos[2],                     
                RolPersonaje.valueOf(datos[3]) 
        );
    }
    
    public static String getHeaderCSV() {
        return "id,nombre,creador,rol";
    }

    
    
    
}
